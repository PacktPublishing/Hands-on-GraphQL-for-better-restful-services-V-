# GraphQL Demo - Restaurant App

A demo restaurant app built using GraphQL, Express, Mongodb, ES6, React and Relay.

## Prerequisites

* Node.js version 9.3.0 or above - For more info visit [nodejs.org](nodejs.org).
* npm version 5.3.0 or above.
* MongoDB version 3.6.1 or above.
* Any code editor - Visual Studio Code (Recommended).
* Any browser - Google Chrome (Recommended).

## Setup

### Module packages

This will install all client and server modules.

```
npm install
```

### Mongodb database & collections

Start Mongodb server instance

```
sudo ./mongo/bin/mongod --dbpath="/Users/ashegde/Documents/restaurant_app/db"
```

Start Mongodb client instance

```
sudo ./mongo/bin/mongo
```

Import initial collections

```
sudo ./mongo/bin/mongoimport --host 127.0.0.1 --port 27017 --db restaurantdb --collection restaurants --drop --file /Users/ashegde/Documents/restaurant_app/code/db/restaurants.json

sudo ./mongo/bin/mongoimport --host 127.0.0.1 --port 27017 --db restaurantdb --collection scoreCategories --drop --file /Users/ashegde/Documents/restaurant_app/code/db/score-categories.json
```
