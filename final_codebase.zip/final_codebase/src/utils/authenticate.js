import Cookies from 'js-cookie';

const authCookieName = 'token';
const userCookieName = 'user';

const UserAuth = {
  isAuthenticate: () => {
    const authCookie = Cookies.get(authCookieName);
    return (authCookie) ? authCookie : false;
  },

  createAuthCookie: (authToken) => {
    Cookies.set(authCookieName, authToken, { expires: 1 });
  },

  removeCookies: () => {
    Cookies.remove(authCookieName);
    Cookies.remove(userCookieName);
  },

  createUserCookie: (userInfo) => {
    Cookies.set(userCookieName, userInfo, { expires: 1 });
  },

  readUserCookie: () => {
    const userCookie = Cookies.get(userCookieName);
    return (userCookie) ? userCookie : false; 
  }
};

export default UserAuth;