function first_name() {
  return {
    // You need to pick a username too
    presence: true,
    // And it must be between 3 and 20 characters long
    length: {
      minimum: 3,
      maximum: 20
    },
    format: {
      // We don't allow anything that a-z and 0-9
      pattern: "[a-z]+",
      // but we don't care if the username is uppercase or lowercase
      flags: "i",
      message: "can only contain a-z"
    }
  };
}

function last_name() {
  return {
    // You need to pick a username too
    presence: true,
    // And it must be between 3 and 20 characters long
    length: {
      minimum: 3,
      maximum: 20
    },
    format: {
      // We don't allow anything that a-z and 0-9
      pattern: "[a-z]+",
      // but we don't care if the username is uppercase or lowercase
      flags: "i",
      message: "can only contain a-z"
    }
  };
}

function email() {
  return {
    // Email is required
    presence: true,
    
    email: true
  };
}

function password() {
  return {
    // Password is also required
    presence: true,
    // And must be at least 5 characters long
    length: {
      minimum: 5
    }
  };
}

module.exports = {
  signUpConstraints: {
    first_name,
    last_name,
    email,
    password
  },

  signInConstraints: {
    email,
    password
  }
}