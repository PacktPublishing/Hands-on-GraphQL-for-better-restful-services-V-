import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';

import UserAuth from '../../utils/authenticate';

class Navbar extends Component {
  constructor(props) {
    super(props);

    this.state = {
      signOut: false
    }
    this.signOut = this.signOut.bind(this);
  }

  signOut() {
    UserAuth.removeCookies();
    this.setState({
      signOut: true
    });
  }

  render() {
    if (this.state.signOut) {
      return <Redirect to="/signout" />;
    }

    return (
			<nav className="navbar navbar-default navbar-fixed-top navbar-component">
        <div className="container">
          <div className="navbar-header">
            <Link to="/" className="navbar-brand">Restaurant App Demo</Link>
          </div>
          {
            this.props.isAuth &&
            <ul className="nav navbar-nav navbar-right">
              <li><button className="btn navbar-btn btn-danger sign-out" onClick={this.signOut}>Sign Out</button></li>
            </ul>
          }
        </div>
      </nav>
		)
	}
}

export default Navbar;