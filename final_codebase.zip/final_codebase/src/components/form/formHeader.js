import React, { Component } from 'react';

class FormHeader extends Component {
	render() {
    return (
      <div className="form-header-component page-header">
        {
          this.props.content &&
          <p className="lead">{this.props.content}</p>
        }
      </div>
		)
	}
}

export default FormHeader;