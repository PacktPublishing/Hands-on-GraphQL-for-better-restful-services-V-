import React, { Component } from 'react';

class Textfield extends Component {
	render() {
    const {
      name,
      label,
      hints,
      isPassword,
      onChangeEvent
    } = this.props;

    let inputType = 'text';
    if (isPassword) {
      inputType = 'password';
    }
    return (
      <div className="form-group">
        <label className="control-label" htmlFor={name}>{label}</label>
        <input onChange={onChangeEvent} name={name} type={inputType} className="form-control" />
        {
          hints &&
          <p className="help-block">{hints}</p>
        }
      </div>
		)
	}
}

export default Textfield;