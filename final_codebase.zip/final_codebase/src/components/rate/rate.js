import './rate.css';
import React, { Component } from 'react';

class Rate extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedOptionValue: false
    };

    this.handleOptionChange = this.handleOptionChange.bind(this);
    this.passSelectedOption = this.passSelectedOption.bind(this);
  }

  handleOptionChange(event) {
    this.setState({
      selectedOptionValue: event.target.value
    });
  }

  passSelectedOption() {
    if (this.state.selectedOptionValue) {
      this.props.hasClick(this.state.selectedOptionValue);
    }
  }

  render() {
    const {
      scoreGrades
    } = this.props;

    return (
			<div className="rate-component panel panel-default">
        <div className="panel-heading">
          <h3 className="panel-title">Rate This Restaurant</h3>
        </div>
        <div className="panel-body">
          <table className="table text-center">
            <tbody>
              <tr onChange={this.handleOptionChange}>
                {
                  scoreGrades.map((scoreGrade) => {
                    return (
                      <td key={scoreGrade._id}>
                        <p className="lead">{scoreGrade.grade}</p>
                        <input type="radio" name="rating" value={scoreGrade._id} />
                      </td>
                    )
                  })
                }
              </tr>
            </tbody>
          </table>

          <button onClick={this.passSelectedOption} className="btn btn-success btn-block">Submit Your Rating</button>
        </div>
      </div>
		)
	}
}

export default Rate;