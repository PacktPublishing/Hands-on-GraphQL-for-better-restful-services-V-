import Alert from './alert';

export default Alert;