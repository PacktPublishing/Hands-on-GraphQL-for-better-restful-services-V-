import React, { Component } from 'react';
import classnames from 'classnames';

class Alert extends Component {
  constructor(props) {
    super(props);

    this.dismissAlert = this.dismissAlert.bind(this);
  }

  dismissAlert() {
    if (this.props.onAlertUnmount) {
      this.props.onAlertUnmount();
    }
  }

	render() {
    const {
      type,
      isDismissible
    } = this.props;

    let alertTypeClass = {
      'alert-component': true,
      'alert': true,
      'alert-dismissible': true,
      [`alert-${type}`]: true
    };
    alertTypeClass = classnames(alertTypeClass);

    return (
      <div className={alertTypeClass} role="alert">
        {
          isDismissible &&
          <button type="button" onClick={this.dismissAlert} className="close"><span aria-hidden="true">&times;</span></button>
        }
        {this.props.children}
      </div>
		)
	}
}

export default Alert;