import './map.css';

import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Map extends Component {
  constructor(props) {
    super(props);

    this.loadMap = this.loadMap.bind(this);
  }

  loadMap({ latitude, longitude }) {
    const targetEl = ReactDOM.findDOMNode(this);
    
    const googleMapAPI = window.google.maps;
    
    const uluru = {lat: Number(latitude), lng: Number(longitude)};
    const map = new googleMapAPI.Map(targetEl, {
      zoom: 5,
      center: uluru
    });
    new googleMapAPI.Marker({
      position: uluru,
      map: map
    });
  }

  componentDidMount() {
    const {
      location
    } = this.props;
    
    this.loadMap(location);
  }

	render() {
    return (
      <div id="map" className="map-container"></div>
		)
	}
}

export default Map;