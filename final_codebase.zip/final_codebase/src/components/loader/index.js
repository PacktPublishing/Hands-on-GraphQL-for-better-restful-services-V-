import Loader from './loader';

export default Loader;