import React, { Component } from 'react';

import Alert from '../alert';

class Error extends Component {
  render() {
    return (
      <Alert type="danger">
        <div className="container">
          <h4>Oops! something went wrong</h4>
          <h5>Sorry, an error occured with our website</h5>
        </div>
      </Alert>
		)
	}
}

export default Error;
