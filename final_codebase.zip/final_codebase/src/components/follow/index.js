import Follow from './follow';

export default Follow;