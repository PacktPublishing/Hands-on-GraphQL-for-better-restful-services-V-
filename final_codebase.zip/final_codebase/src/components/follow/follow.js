import './follow.css';

import React, { Component } from 'react';
import classnames from 'classnames';

class Follow extends Component {
	render() {
    let followText = "I want to follow this restaurant";
    let followBtnClass = {
      'btn': true,
      'btn-block': true,
      'btn-success': true,
      'unfollowing': true
    };

    if (this.props.isFollowing) {
      followText = "I don't want to follow this restaurant";

      followBtnClass = {
        'btn': true,
        'btn-block': true,
        'btn-success': false,
        'btn-danger': true,
        'unfollowing': false,
        'following': true
      };
    }

    followBtnClass = classnames(followBtnClass);

    return (
      <div className="follow-component">
        <button onClick={this.props.hasClick} className={followBtnClass}>{followText}</button>
      </div>
		)
	}
}

export default Follow;