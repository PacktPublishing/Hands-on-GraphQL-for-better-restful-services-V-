import './index.css';
import ReactDOM from 'react-dom';
import DefinedRoutes from './router/routes';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(DefinedRoutes, document.getElementById('root'));
registerServiceWorker();
