import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Link, Redirect } from 'react-router-dom';
import validate from 'validate.js';
import { commitMutation, graphql } from 'react-relay';
import environment from '../../environment';

import UserAuth from '../../utils/authenticate';
import Alert from '../../components/alert';
import FormHeader from '../../components/form/formHeader';
import TextField from '../../components/form/textField';
import { signInConstraints } from '../../utils/fieldRules';

class SignInPage extends Component {
	constructor(props) {
		super(props);

		this.state = {
			email: '',
			password: '',
			errorMsgs: [],
			showAlert: false,
			redirectToHome: false,
			hasClientError: false,
			hasServerError: false,
			enableServiceCall: false
		};

		this.validateForm = this.validateForm.bind(this);
		this.submitValidInfo = this.submitValidInfo.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleAlertUnmount = this.handleAlertUnmount.bind(this);
	}

	handleAlertUnmount() {
		this.setState({
			showAlert: false
		});
	}

	handleChange(event) {
		event.preventDefault();
		const targetEl = ReactDOM.findDOMNode(event.target);
		const { name, value } = targetEl;

		this.setState({
			[name]: value
		});
	}

	signInHandshake(mutation, variables) {
		return new Promise((resolve, reject) => {
			commitMutation(
				environment,
				{
					mutation,
					variables,
					onCompleted: (response, error) => {
						if (error) {
							const errorMsgs = [];
							errorMsgs.push(error[0].message);
							return reject(errorMsgs);
						}
						
						UserAuth.createAuthCookie(response.signIn.token);

						return resolve(response);
					},
					onError: (error) => {
						return reject(error);
					}
				}
			);
		});
	}
	
	submitValidInfo() {
		const mutation = graphql`
			mutation signInMutation (
				$email: String!
				$password: String!
			) {
				signIn (
					email: $email
					password: $password
				) {
					user {
						email
					}
					token
				}
			}
		`;

		const variables = {
			email: this.state.email,
			password: this.state.password
		};

		this.signInHandshake(mutation, variables)
			.then((response) => {
				this.setState({
					errorMsgs: [],
					showAlert: false,
					redirectToHome: true,
					enableServiceCall: false
				});
			})
			.catch((error) => {
				this.setState({
					errorMsgs: error,
					showAlert: true,
					hasServerError: true,
					enableServiceCall: false
				});
			});
	}

	validateForm(event) {
		event.preventDefault();

		const targetEl = ReactDOM.findDOMNode(event.target);
		const errors = validate(targetEl, signInConstraints);

		if (errors) {
			let errorMsgs = [];
			if(errors.hasOwnProperty('email')) {
				errorMsgs.push(errors.email[0]);
			}
			if(errors.hasOwnProperty('password')) {
				errorMsgs.push(errors.password[0]);
			}

			this.setState({
				errorMsgs: errorMsgs,
				showAlert: true,
				hasClientError: true,
				enableServiceCall: false
			});
			return false;
		}

		this.setState({
			hasClientError: false,
			enableServiceCall: true		
		});
	}

	errorDisplayFormat(errorMsgs) {
		return errorMsgs.map((errorMsg, index) => {
			return (
				<h6 key={index}>{errorMsg}</h6>
			)
		});
	} 

	render() {
		if (this.state.redirectToHome) {
			return <Redirect to="/restaurants" />;
		}

		const redirectToSignUp = (
			<span><Link to="signup">Sign Up</Link> to create your account.</span>
		);

		let alertState = "danger";
		let alertContent = (
			<div>
				<h4>Oh! something went wrong</h4>
				<h5>Change a few things up and try submitting again</h5>
				<hr/>
				{
					this.errorDisplayFormat(this.state.errorMsgs)
				}
			</div>
		);
		
		if (this.state.enableServiceCall) {
			this.submitValidInfo();
		}

		return (
			<div className="sign-page">
				<div className="sign-in-component col-md-6 col-md-offset-3">
					<FormHeader content={redirectToSignUp} />

					<form name="sign-in-form" onSubmit={this.validateForm}>
						<FormHeader content="Sign-In to your account" />

						{
							this.state.showAlert &&
							<Alert onAlertUnmount={this.handleAlertUnmount} type={alertState} isDismissible={true}>{alertContent}</Alert>
						}

						<TextField
							name="email"
							label="Enter your email"
							hints="Email of your is require"
							onChangeEvent={this.handleChange} />

						<TextField
							name="password"
							label="Enter your password"
							hints="Password of your is require"
							onChangeEvent={this.handleChange}
							isPassword={true} />

						<button type="submit" className="btn btn-primary sign-in">Sign In</button>
					</form>
				</div>
			</div>
		)
	}
}

export default SignInPage;