import SignInPage from './signIn';

export default SignInPage;