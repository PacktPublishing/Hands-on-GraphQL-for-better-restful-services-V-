import SignUpPage from './signUp';

export default SignUpPage;