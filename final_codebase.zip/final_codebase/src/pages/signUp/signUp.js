import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router-dom';
import validate from 'validate.js';

import { commitMutation, graphql } from 'react-relay';
import environment from '../../environment';

import Alert from '../../components/alert';
import FormHeader from '../../components/form/formHeader';
import TextField from '../../components/form/textField';
import { signUpConstraints } from '../../utils/fieldRules';

class SignUpPage extends Component {
	constructor(props) {
		super(props);

		this.state = {
			first_name: '',
			last_name: '',
			email: '',
			password: '',
			errorMsgs: [],
			showAlert: false,
			userAccountCreated: false,
			hasClientError: false,
			hasServerError: false,
			enableServiceCall: false
		};

		this.validateForm = this.validateForm.bind(this);
		this.submitValidInfo = this.submitValidInfo.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleAlertUnmount = this.handleAlertUnmount.bind(this);
	}

	handleAlertUnmount() {
		this.setState({
			showAlert: false
		});
	}

	handleChange(event) {
		event.preventDefault();
		const targetEl = ReactDOM.findDOMNode(event.target);
		const { name, value } = targetEl;

		this.setState({
			[name]: value
		});
	}
	
	signUpHandshake(mutation, variables) {
		return new Promise((resolve, reject) => {
			commitMutation(
				environment,
				{
					mutation,
					variables,
					onCompleted: (response, error) => {
						if (error) {
							const errorMsgs = [];
							errorMsgs.push(error[0].message);
							return reject(errorMsgs);
						}

						return resolve(response);
					},
					onError: (error) => {
						return reject(error);
					}
				}
			);
		});
	}

	submitValidInfo() {
		const mutation = graphql`
			mutation signUpMutation (
				$first_name: String!
				$last_name: String!
				$email: String!
				$password: String!
			) {
				signUp (
					first_name: $first_name
					last_name: $last_name
					email: $email
					password: $password
				) {
					_id
					first_name,
					last_name,
					email
				}
			}
		`;

		const variables = {
			first_name: this.state.first_name,
			last_name: this.state.last_name,
			email: this.state.email,
			password: this.state.password
		};

		this.signUpHandshake(mutation, variables)
			.then((response) => {
				this.setState({
					errorMsgs: [],
					showAlert: true,
					userAccountCreated: true,
					enableServiceCall: false
				});
			})
			.catch((error) => {
				this.setState({
					errorMsgs: error,
					showAlert: true,
					hasServerError: true,
					enableServiceCall: false
				});
			});
	}

	validateForm(event) {
		event.preventDefault();

		const targetEl = ReactDOM.findDOMNode(event.target);
		const errors = validate(targetEl, signUpConstraints);

		if (errors) {
			let errorMsgs = [];
			if(errors.hasOwnProperty('first_name')) {
				errorMsgs.push(errors.first_name[0]);
			}
			if(errors.hasOwnProperty('last_name')) {
				errorMsgs.push(errors.last_name[0]);
			}
			if(errors.hasOwnProperty('email')) {
				errorMsgs.push(errors.email[0]);
			}
			if(errors.hasOwnProperty('password')) {
				errorMsgs.push(errors.password[0]);
			}

			this.setState({
				errorMsgs: errorMsgs,
				showAlert: true,
				hasClientError: true,
				enableServiceCall: false
			});
			return false;
		}

		this.setState({
			hasClientError: false,
			enableServiceCall: true		
		});
	}

	errorDisplayFormat(errorMsgs) {
		return errorMsgs.map((errorMsg, index) => {
			return (
				<h6 key={index}>{errorMsg}</h6>
			)
		});
	} 

	render() {
		
		const redirectToSignIn = (
			<span>Already have your account then <Link to="signin">Sign In</Link></span>
		);

		let alertState = "danger";
		let alertContent = (
			<div>
				<h4>Oh! something went wrong</h4>
				<h5>Change a few things up and try submitting again</h5>
				<hr/>
				{
					this.errorDisplayFormat(this.state.errorMsgs)
				}
			</div>
		);

		if (this.state.userAccountCreated) {
			alertState = "success";

			alertContent = (
				<div>
					<h4>Well done! {this.state.first_name} {this.state.last_name}.</h4>
					<h5>You successfully signed up. Now you can <Link to="signin">Sign In</Link> to your account.</h5>
				</div>
			);
		}

		if (this.state.enableServiceCall) {
			this.submitValidInfo();
		}

		return (
			<div className="sign-page">
				<div className="sign-up-component col-md-6 col-md-offset-3">
					<FormHeader content={redirectToSignIn} />

					<form name="sign-up-form" onSubmit={this.validateForm}>
						<FormHeader content="Create your account" />

						{
							this.state.showAlert &&
							<Alert onAlertUnmount={this.handleAlertUnmount} type={alertState} isDismissible={true}>{alertContent}</Alert>
						}

						<TextField
							name="first_name"
							label="Enter your first name"
							hints="First name of your is require and only alphabets are allowed with min. 3 characters"
							onChangeEvent={this.handleChange} />

						<TextField
							name="last_name"
							label="Enter your last name"
							hints="Last name of your is require and only alphabets are allowed with min. 3 characters"
							onChangeEvent={this.handleChange} />

						<TextField
							name="email"
							label="Enter your email"
							hints="Email of your is require"
							onChangeEvent={this.handleChange} />

						<TextField
							name="password"
							label="Enter your password"
							hints="Password of your is require and it needs min. 5 characters"
							onChangeEvent={this.handleChange}
							isPassword={true} />

						<button type="submit" className="btn btn-primary sign-up">Sign Up</button>
					</form>
				</div>
			</div>
		)
	}
}

export default SignUpPage;

