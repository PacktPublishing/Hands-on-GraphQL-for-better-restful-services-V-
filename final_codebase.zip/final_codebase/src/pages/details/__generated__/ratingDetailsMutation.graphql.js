/**
 * @flow
 * @relayHash c2b94b7e53bfdf94efffa1244a74983e
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type ratingDetailsMutationVariables = {|
  user_id: string;
  restaurant_id: string;
  score_id: string;
|};
export type ratingDetailsMutationResponse = {|
  +rate: ?{|
    +isRating: ?boolean;
  |};
|};
*/


/*
mutation ratingDetailsMutation(
  $user_id: String!
  $restaurant_id: String!
  $score_id: String!
) {
  rate(user_id: $user_id, restaurant_id: $restaurant_id, score_id: $score_id) {
    isRating
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "restaurant_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "score_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "ratingDetailsMutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "score_id",
            "variableName": "score_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Rate",
        "name": "rate",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isRating",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Mutation"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "ratingDetailsMutation",
  "query": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "restaurant_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "score_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Root",
    "name": "ratingDetailsMutation",
    "operation": "mutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "score_id",
            "variableName": "score_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Rate",
        "name": "rate",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isRating",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "mutation ratingDetailsMutation(\n  $user_id: String!\n  $restaurant_id: String!\n  $score_id: String!\n) {\n  rate(user_id: $user_id, restaurant_id: $restaurant_id, score_id: $score_id) {\n    isRating\n  }\n}\n"
};

module.exports = batch;
