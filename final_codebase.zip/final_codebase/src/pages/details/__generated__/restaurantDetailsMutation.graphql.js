/**
 * @flow
 * @relayHash 98f8a4b6d3b2744fba5d6efe9f9c4a2f
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type restaurantDetailsMutationVariables = {|
  user_id: string;
  restaurant_id: string;
|};
export type restaurantDetailsMutationResponse = {|
  +follow: ?{|
    +isFollowing: ?boolean;
  |};
|};
*/


/*
mutation restaurantDetailsMutation(
  $user_id: String!
  $restaurant_id: String!
) {
  follow(user_id: $user_id, restaurant_id: $restaurant_id) {
    isFollowing
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "restaurant_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "restaurantDetailsMutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Follow",
        "name": "follow",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isFollowing",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Mutation"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "restaurantDetailsMutation",
  "query": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "restaurant_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Root",
    "name": "restaurantDetailsMutation",
    "operation": "mutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Follow",
        "name": "follow",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isFollowing",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "mutation restaurantDetailsMutation(\n  $user_id: String!\n  $restaurant_id: String!\n) {\n  follow(user_id: $user_id, restaurant_id: $restaurant_id) {\n    isFollowing\n  }\n}\n"
};

module.exports = batch;
