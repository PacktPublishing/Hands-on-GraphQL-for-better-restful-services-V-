/**
 * @flow
 * @relayHash 0280351961fa8c15556cc0daf6176814
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type detailsQueryResponse = {|
  +restaurant: ?{|
    +name: string;
    +cuisine: string;
    +district: string;
    +address: ?{|
      +street: string;
      +city: string;
      +zipcode: string;
      +region: ?string;
      +country: string;
      +coord: ?{|
        +latitude: ?string;
        +longitude: ?string;
      |};
    |};
  |};
  +follow: ?{|
    +isFollowing: ?boolean;
  |};
  +scoreGrades: ?$ReadOnlyArray<?{|
    +_id: ?string;
    +grade: ?string;
  |}>;
  +rate: ?{|
    +isRating: ?boolean;
  |};
  +stats: ?{|
    +avg: ?number;
  |};
|};
*/


/*
query detailsQuery(
  $_user_id: String!
  $_restaurant_id: String!
) {
  restaurant(restaurant_id: $_restaurant_id) {
    name
    cuisine
    district
    address {
      street
      city
      zipcode
      region
      country
      coord {
        latitude
        longitude
      }
    }
  }
  follow(user_id: $_user_id, restaurant_id: $_restaurant_id) {
    isFollowing
  }
  scoreGrades {
    _id
    grade
  }
  rate(user_id: $_user_id, restaurant_id: $_restaurant_id) {
    isRating
  }
  stats(restaurant_id: $_restaurant_id) {
    avg
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "_user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "_restaurant_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "detailsQuery",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          }
        ],
        "concreteType": "Restaurant",
        "name": "restaurant",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "name",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "cuisine",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "district",
            "storageKey": null
          },
          {
            "kind": "LinkedField",
            "alias": null,
            "args": null,
            "concreteType": "Address",
            "name": "address",
            "plural": false,
            "selections": [
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "street",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "city",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "zipcode",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "region",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "country",
                "storageKey": null
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "args": null,
                "concreteType": "Coordinates",
                "name": "coord",
                "plural": false,
                "selections": [
                  {
                    "kind": "ScalarField",
                    "alias": null,
                    "args": null,
                    "name": "latitude",
                    "storageKey": null
                  },
                  {
                    "kind": "ScalarField",
                    "alias": null,
                    "args": null,
                    "name": "longitude",
                    "storageKey": null
                  }
                ],
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "_user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Follow",
        "name": "follow",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isFollowing",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": null,
        "concreteType": "ScoreGrades",
        "name": "scoreGrades",
        "plural": true,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "grade",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "_user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Rate",
        "name": "rate",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isRating",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          }
        ],
        "concreteType": "Stats",
        "name": "stats",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "avg",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Query"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "detailsQuery",
  "query": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "_user_id",
        "type": "String!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "_restaurant_id",
        "type": "String!",
        "defaultValue": null
      }
    ],
    "kind": "Root",
    "name": "detailsQuery",
    "operation": "query",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          }
        ],
        "concreteType": "Restaurant",
        "name": "restaurant",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "name",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "cuisine",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "district",
            "storageKey": null
          },
          {
            "kind": "LinkedField",
            "alias": null,
            "args": null,
            "concreteType": "Address",
            "name": "address",
            "plural": false,
            "selections": [
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "street",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "city",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "zipcode",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "region",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "country",
                "storageKey": null
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "args": null,
                "concreteType": "Coordinates",
                "name": "coord",
                "plural": false,
                "selections": [
                  {
                    "kind": "ScalarField",
                    "alias": null,
                    "args": null,
                    "name": "latitude",
                    "storageKey": null
                  },
                  {
                    "kind": "ScalarField",
                    "alias": null,
                    "args": null,
                    "name": "longitude",
                    "storageKey": null
                  }
                ],
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "_user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Follow",
        "name": "follow",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isFollowing",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": null,
        "concreteType": "ScoreGrades",
        "name": "scoreGrades",
        "plural": true,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "grade",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          },
          {
            "kind": "Variable",
            "name": "user_id",
            "variableName": "_user_id",
            "type": "String!"
          }
        ],
        "concreteType": "Rate",
        "name": "rate",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "isRating",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "restaurant_id",
            "variableName": "_restaurant_id",
            "type": "String!"
          }
        ],
        "concreteType": "Stats",
        "name": "stats",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "avg",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "query detailsQuery(\n  $_user_id: String!\n  $_restaurant_id: String!\n) {\n  restaurant(restaurant_id: $_restaurant_id) {\n    name\n    cuisine\n    district\n    address {\n      street\n      city\n      zipcode\n      region\n      country\n      coord {\n        latitude\n        longitude\n      }\n    }\n  }\n  follow(user_id: $_user_id, restaurant_id: $_restaurant_id) {\n    isFollowing\n  }\n  scoreGrades {\n    _id\n    grade\n  }\n  rate(user_id: $_user_id, restaurant_id: $_restaurant_id) {\n    isRating\n  }\n  stats(restaurant_id: $_restaurant_id) {\n    avg\n  }\n}\n"
};

module.exports = batch;
