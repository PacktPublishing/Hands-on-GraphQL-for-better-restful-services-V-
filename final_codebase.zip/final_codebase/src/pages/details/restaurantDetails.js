import React, { Component } from 'react';

import {
  commitMutation,
  graphql
} from 'react-relay';

import environment from '../../environment';
import Map from '../../components/map';
import Follow from '../../components/follow';
import RatingDetails from './ratingDetails';

class RestaurantDetails extends Component {
  constructor(props) {
    super(props);
  
    this.followRestaurant = this.followRestaurant.bind(this);
  }

  handshake(mutation, variables) {
    return new Promise((resolve, reject) => {
      commitMutation(
        environment,
        {
          mutation,
          variables,
          onCompleted: (response, error) => {
            if (error) {
              const errorMsgs = [];
              errorMsgs.push(error[0].message);
              return reject(errorMsgs);
            }
  
            return resolve(response);
          },
          onError: (error) => {
            return reject(error);
          }
        }
      );
    });
  }
  
  followRestaurant() {
    const mutation = graphql`
      mutation restaurantDetailsMutation (
        $user_id: String!
        $restaurant_id: String!
      ) {
        follow (
          user_id: $user_id
          restaurant_id: $restaurant_id
        ) {
          isFollowing
        }
      }
    `;
    
    const {
      _user_id,
      _restaurant_id
    } = this.props._ids;
  
    const variables = {
      user_id: _user_id,
      restaurant_id: _restaurant_id
    };
  
    this.handshake(mutation, variables)
      .catch((error) => {
        console.log('Error: ', error);
      });
  }

	render() {
    const {
      name,
      district,
      cuisine,
      address
    } = this.props.restaurant;
    
    const {
      street,
      region,
      city,
      zipcode,
      country,
      coord
    } = address;

    const {
      isFollowing
    } = this.props.follow;

    let {
      avg
    } = this.props.stats;
    
    if (!avg) {
      avg = ''
    }
    
		return (
      <div className="restaurant-details-component">
        <div className="page-header">
          <h1>{name}<small>, {cuisine} cuisine </small> 
          {
            avg &&
            <span className="label label-info">{avg}</span>
          }
          </h1>

          <p className="lead">
            <span className="glyphicon glyphicon-map-marker text-primary"></span> {district}
            {
              street &&
              <span>, {street}</span>
            }
            {
              region &&
              <span>, {region}</span>
            }
            {
              city &&
              <span>, {city}</span>
            }
            {
              zipcode &&
              <span>, {zipcode}</span>
            }
            {
              country &&
              <span>, {country}</span>
            }
          </p>
        </div>
        
        <Map location={coord} />

        <Follow hasClick={this.followRestaurant} isFollowing={isFollowing}/>

        <RatingDetails
          _ids={this.props._ids}
          rate={this.props.rate}
          scoreGrades={this.props.scoreGrades} />
      </div>
    )
	}
}

export default RestaurantDetails;