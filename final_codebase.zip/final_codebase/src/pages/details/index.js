import DetailsPage from './details';

export default DetailsPage;