import React, { Component } from 'react';
import {
  commitMutation,
  graphql
} from 'react-relay';
import environment from '../../environment';

import Rate from '../../components/rate';

class RatingDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      enableRating: this.props.rate.isRating
    };

    this.rateRestaurant = this.rateRestaurant.bind(this);
  }

  handshake(mutation, variables) {
		return new Promise((resolve, reject) => {
			commitMutation(
				environment,
				{
					mutation,
					variables,
					onCompleted: (response, error) => {
						if (error) {
							const errorMsgs = [];
							errorMsgs.push(error[0].message);
							return reject(errorMsgs);
						}

						return resolve(response);
					},
					onError: (error) => {
						return reject(error);
					}
				}
			);
		});
  }

  rateRestaurant(_score_id) {

    const mutation = graphql`
			mutation ratingDetailsMutation (
				$user_id: String!
        $restaurant_id: String!
        $score_id: String!
			) {
				rate (
					user_id: $user_id
          restaurant_id: $restaurant_id
          score_id: $score_id
				) {
					isRating
				}
			}
		`;
    
    const {
      _user_id,
      _restaurant_id
    } = this.props._ids;

		const variables = {
			user_id: _user_id,
      restaurant_id: _restaurant_id,
      score_id: _score_id
		};

		this.handshake(mutation, variables)
			.then((response) => {
        this.setState({
          enableRating: response.rate.isRating
        })
			})
			.catch((error) => {
        console.log('Error: ', error);
			});
  }

	render() {
    return (
      <div className="rating-details-component">
        {
          !this.state.enableRating && 
          <Rate hasClick={this.rateRestaurant} scoreGrades={this.props.scoreGrades} />
        }
      </div>
    )
	}
}

export default RatingDetails;