import React, { Component } from 'react';

import {
  QueryRenderer,
  graphql
} from 'react-relay';
import environment from '../../environment';

import UserAuth from '../../utils/authenticate';
import RestaurantDetails from './restaurantDetails';
import Loader from '../../components/loader';
import Error from '../../components/error';

class DetailsPage extends Component { 
	render() {
		const _ids = {
			_user_id: UserAuth.readUserCookie(),
			_restaurant_id: this.props.match.params.rid
		};

		const query = graphql`
			query detailsQuery (
				$_user_id: String!
				$_restaurant_id: String!
			) {
				restaurant (
					restaurant_id: $_restaurant_id
				) {
					name
					cuisine
					district
					address {
						street
						city
						zipcode
						region
						country
						coord {
							latitude
							longitude
						}
					}
				}
				follow (
					user_id: $_user_id,
					restaurant_id: $_restaurant_id
				) {
					isFollowing
				}
				scoreGrades {
					_id
					grade
				}
				rate (
					user_id: $_user_id,
					restaurant_id: $_restaurant_id
				) {
					isRating
				}
				stats (
					restaurant_id: $_restaurant_id
				) {
					avg
				}
			}
		`;

    return (
			<QueryRenderer
				environment={environment}
				query={query}
				variables={_ids}
				render={({error, props}) => {
					
					if (error) {
						return <Error />;
					}

					if (!props) {
						return <Loader />;
					}

					return (
						<div className="details-component">
							<RestaurantDetails 
								restaurant = {props.restaurant}
								follow = {props.follow}
								scoreGrades = {props.scoreGrades}
								rate = {props.rate}
								stats = {props.stats}
								_ids = {_ids}
							/>
						</div>
					)
				}}
			/>
		)
	}
}

export default DetailsPage;