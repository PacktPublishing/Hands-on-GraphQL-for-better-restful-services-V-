import ErrorPage from './errors';

export default ErrorPage;