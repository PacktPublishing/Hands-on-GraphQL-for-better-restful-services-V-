import React, { Component } from 'react';

class ErrorPage extends Component {
	render() {
		return (
      <div className="error-page jumbotron text-center">
				<div className="container">
					<h2>Page not found</h2>
					<p className="lead">
						Uh oh, we can’t seem to find the page you’re looking for.
						Try going back to the previous page.
					</p>
				</div>
			</div>
		)
	}
}

export default ErrorPage;