import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class RestaurantsLink extends Component {
	render() {
		return (
			<tbody>
        {
          this.props.datalist.map(({ _id, name }) => {
            
            let _idRoute = `/restaurants/${_id}`;

            return (
              <tr key={_id} className="restaurant-row">
                <td><Link to={_idRoute}>{name}</Link></td>
              </tr>
            )
          })
        }
      </tbody>
		)
	}
}

export default RestaurantsLink;