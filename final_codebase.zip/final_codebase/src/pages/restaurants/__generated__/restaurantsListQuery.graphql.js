/**
 * @flow
 * @relayHash 5ac18ac7c07bda7a5e90e032e737a5b5
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type restaurantsListQueryResponse = {|
  +restaurants: ?$ReadOnlyArray<?{|
    +_id: ?string;
    +name: string;
  |}>;
|};
*/


/*
query restaurantsListQuery(
  $_from: Int
  $_pageSize: Int
) {
  restaurants(from: $_from, pageSize: $_pageSize) {
    _id
    name
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "_from",
        "type": "Int",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "_pageSize",
        "type": "Int",
        "defaultValue": null
      }
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "restaurantsListQuery",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "from",
            "variableName": "_from",
            "type": "Int"
          },
          {
            "kind": "Variable",
            "name": "pageSize",
            "variableName": "_pageSize",
            "type": "Int"
          }
        ],
        "concreteType": "Restaurant",
        "name": "restaurants",
        "plural": true,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "name",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Query"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "restaurantsListQuery",
  "query": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "_from",
        "type": "Int",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "_pageSize",
        "type": "Int",
        "defaultValue": null
      }
    ],
    "kind": "Root",
    "name": "restaurantsListQuery",
    "operation": "query",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "from",
            "variableName": "_from",
            "type": "Int"
          },
          {
            "kind": "Variable",
            "name": "pageSize",
            "variableName": "_pageSize",
            "type": "Int"
          }
        ],
        "concreteType": "Restaurant",
        "name": "restaurants",
        "plural": true,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "name",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "query restaurantsListQuery(\n  $_from: Int\n  $_pageSize: Int\n) {\n  restaurants(from: $_from, pageSize: $_pageSize) {\n    _id\n    name\n  }\n}\n"
};

module.exports = batch;
