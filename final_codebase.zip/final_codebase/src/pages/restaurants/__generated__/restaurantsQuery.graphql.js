/**
 * @flow
 * @relayHash 006d0e708b84db7d7a162d7cf60c167c
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type restaurantsQueryResponse = {|
  +myself: ?{|
    +_id: ?string;
    +first_name: string;
    +last_name: string;
  |};
|};
*/


/*
query restaurantsQuery {
  myself {
    _id
    first_name
    last_name
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [],
    "kind": "Fragment",
    "metadata": null,
    "name": "restaurantsQuery",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": null,
        "concreteType": "User",
        "name": "myself",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "first_name",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "last_name",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Query"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "restaurantsQuery",
  "query": {
    "argumentDefinitions": [],
    "kind": "Root",
    "name": "restaurantsQuery",
    "operation": "query",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": null,
        "concreteType": "User",
        "name": "myself",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "_id",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "first_name",
            "storageKey": null
          },
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "last_name",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "query restaurantsQuery {\n  myself {\n    _id\n    first_name\n    last_name\n  }\n}\n"
};

module.exports = batch;
