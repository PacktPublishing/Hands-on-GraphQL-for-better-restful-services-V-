import React, { Component } from 'react';
import {
  QueryRenderer,
  graphql
} from 'react-relay';
import environment from '../../environment';
import Loader from '../../components/loader';
import Error from '../../components/error';

import RestaurantsLink from './restaurantsLink';

class RestaurantsList extends Component {
	constructor(props) {
		super(props);
	
		this.cacheDatalist = [];
		this.state = {
			from: 0,
			pageSize: 5,
			hasMore: true
		};
		this._loadMore = this._loadMore.bind(this);
	}
	
	_loadMore() {
		this.setState({
			from: this.cacheDatalist.length + 1,
			pageSize: 5
		});
	}

	render() {
		const query = graphql`
			query restaurantsListQuery (
				$_from: Int
				$_pageSize: Int
			) {
				restaurants (
					from: $_from
					pageSize: $_pageSize
				) {
					_id
					name
				}
			}
		`;

		return (
			<QueryRenderer
				environment={environment}
				query={query}
				variables={{
					_from: this.state.from,
					_pageSize: this.state.pageSize
				}}
				render={({error, props}) => {
		
					if (error) {
						return <Error />;
					}
		
					if (!props) {
						return <Loader />;
					}
					
					this.cacheDatalist = this.cacheDatalist.concat(props.restaurants);
					
					return (
						<div className="restaurants-list-component">
							<table className="table table-hover">
								<thead>
									<tr>
										<th>Restaurants</th>
									</tr>
								</thead>
								<RestaurantsLink datalist={this.cacheDatalist} />
							</table>
							{
								this.state.hasMore && 
								<button onClick={this._loadMore} className="btn btn-block btn-primary load-more">Load More</button>
							}
						</div>
					)
				}}
			/>
		)
	}
}

export default RestaurantsList;