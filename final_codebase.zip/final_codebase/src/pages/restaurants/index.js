import RestaurantsPage from './restaurants';

export default RestaurantsPage;