import React, { Component } from 'react';

import {
  QueryRenderer,
  graphql
} from 'react-relay';

import environment from '../../environment';

import UserAuth from '../../utils/authenticate';
import RestaurantsList from './restaurantsList';
import Loader from '../../components/loader';
import Error from '../../components/error';

class RestaurantsPage extends Component {
  render() {
    const query = graphql`
      query restaurantsQuery {
        myself {
          _id
          first_name
          last_name
        }
      }
    `;

    return (
      <QueryRenderer
        environment={environment}
        query={query}
        render={({error, props}) => {

          if (error) {
            return <Error />;
          }

          if (!props) {
            return <Loader />;
          }

          const {
            _id,
            first_name,
            last_name
          } = props.myself;
          
          UserAuth.createUserCookie(_id);

          return (
            <div className="restaurants-component">
              <p className="lead">Welcome, {first_name} {last_name}</p>
              <RestaurantsList />
            </div>
          )
        }}
      />
		)
	}
}

export default RestaurantsPage;