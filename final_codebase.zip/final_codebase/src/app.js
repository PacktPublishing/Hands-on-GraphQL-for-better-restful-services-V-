import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-theme.css';

import React, { Component } from 'react';
import Navbar from './components/navbar';

import UserAuth from './utils/authenticate';

class App extends Component {
  render() {
    let renderNavbar = '';
    const isAuth = UserAuth.isAuthenticate();
    if (isAuth) {
      renderNavbar = (
        <Navbar isAuth={isAuth} />
      )
    }

    return (
      <div className="container">
        {renderNavbar}
        {this.props.children}
      </div>
    )
  }
}

export default App;
