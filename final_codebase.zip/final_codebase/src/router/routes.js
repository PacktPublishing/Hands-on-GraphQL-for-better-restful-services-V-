import React from 'react';
import { 
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from 'react-router-dom';

// Import root app
import App from '../app.js';
import UserAuth from '../utils/authenticate';

// Import page level components
import RestaurantsPage from '../pages/restaurants';
import DetailsPage from '../pages/details';
import ErrorPage from '../pages/errors';
import SignUpPage from '../pages/signUp';
import SignInPage from '../pages/signIn';

// Private Routes
const PrivateRoute = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render = {props =>
      UserAuth.isAuthenticate() ? (
        <Component {...props} />
      ) : (
        <Redirect
          to={{
            pathname: "/signin",
            state: { from: props.location }
          }}
        />
      )
    }
  />
);

const ProtectedRoute = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render = {props =>
      UserAuth.isAuthenticate() ? (
        <Redirect
          to={{
            pathname: "/restaurants",
            state: { from: props.location }
          }}
        />
      ) : (
        <Component {...props} />
      )
    }
  />
);

// Construct application routes
const Routes = (
  <Router>
    <App>
      <Switch>
        <ProtectedRoute exact path = "/" component = {SignInPage} />
        <ProtectedRoute exact path = "/signin" component = {SignInPage} />
        <Redirect from = "/signout" to = "/" />
        <ProtectedRoute exact path = "/signup" component = {SignUpPage} />

        <PrivateRoute exact path = "/restaurants" component = {RestaurantsPage} />
        <PrivateRoute exact path = "/restaurants/:rid" component = {DetailsPage} />

        <Route component={ErrorPage}/>
      </Switch>
    </App>
  </Router>
);

export default Routes;
