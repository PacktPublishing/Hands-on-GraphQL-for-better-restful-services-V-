const {
  GraphQLObjectType,
  GraphQLSchema,
  GraphQLString,
  GraphQLBoolean,
  GraphQLInt,
  GraphQLList,
  GraphQLError,
  GraphQLNonNull
} = require('graphql');

// Schemas
const {
  RestaurantType,
  FollowType,
  RateType,
  StatsType
} = require('./restaurant/schema');
const { UserType } = require('./user/schema');
const { AuthenticateType } = require('./authentication/schema');
const { ScoreType } = require('./scores/schema');

// Resolvers
const {
  allRestaurants,
  restaurant,
  toggleFollowStatus,
  followStatus,
  rateStatus,
  rateRestaurant,
  rateStats
} = require('./restaurant/resolver');
const { signUp, signIn } = require('./authentication/resolver');
const { allScoreGrades } = require('./scores/resolver');

const {
  verifyToken
} = require('../libs/security');

const {
  isEmail,
  isValidRange
} = require('../libs/validation');

// Root Queries
const Query = new GraphQLObjectType({
  name: 'QueryType',
  fields: () => ({
    restaurant: {
      type: RestaurantType,
      description: 'Return a specific restaurant details',
      args: {
        restaurant_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        return restaurant(reqObject)
          .catch((error) => new GraphQLError(error));
      }
    },
    restaurants: {
      type: new GraphQLList(RestaurantType),
      description: 'Return all the restaurants',
      args: {
        from: {
          type: GraphQLInt
        },
        pageSize: {
          type: GraphQLInt
        }
      },
      resolve(parentValue, args, { mongo }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };

        args.from = args.from || 0;
        args.pageSize = args.pageSize || 5;

        return allRestaurants(reqObject)
          .catch((error) => new GraphQLError(error));
      }
    },
    myself: {
      type: UserType,
      description: 'Return a specific user details',
      resolve(parentValue, args, { req }) {
        return verifyToken(req.headers.authorization)
          .then((user) => {
            return user;
          })
          .catch((error) => new GraphQLError(error));
      }
    },
    follow: {
      type: FollowType,
      description: 'Return if restaurant is already followed by the user',
      args: {
        user_id: {
          type: GraphQLString
        },
        restaurant_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        return followStatus(reqObject);
      }
    },
    rate: {
      type: RateType,
      description: 'Return if restaurant is already rated by the user',
      args: {
        user_id: {
          type: GraphQLString
        },
        restaurant_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        return rateStatus(reqObject);
      }
    },
    stats: {
      type: StatsType,
      description: 'Return a specific restaurant avg rating',
      args: {
        restaurant_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo, req }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        return rateStats(reqObject)
          .catch((error) => new GraphQLError(error));
      }
    },
    scoreGrades: {
      type: new GraphQLList(ScoreType),
      description: 'Return all the score grades',
      resolve(parentValue, args, { mongo }) {
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        return allScoreGrades(reqObject);
      }
    },
  })
});

// Root Mutations
const Mutation = new GraphQLObjectType({
  name: 'MutationType',
  fields: () => ({
    signUp: {
      type: UserType,
      args: {
        first_name: {
          type: new GraphQLNonNull(GraphQLString)
        },
        last_name: {
          type: new GraphQLNonNull(GraphQLString)
        },
        email: {
          type: new GraphQLNonNull(GraphQLString)
        },
        password: {
          type: new GraphQLNonNull(GraphQLString)
        }
      },
      resolve(parentValue, args, { mongo }) {
        if (!isEmail(args.email)) {
          return new GraphQLError('Email is incorrect!');
        }
        
        if (!isValidRange(args.password, { min: 5 })) {
          return new GraphQLError('Password length is incorrect!');
        }
        
        if (!isValidRange(args.first_name)) {
          return new GraphQLError('First name length is incorrect!');
        }
        
        if (!isValidRange(args.last_name)) {
          return new GraphQLError('Last name length is incorrect!');
        }

        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        
        return signUp(reqObject)
          .catch((error) => new GraphQLError(error));
      }
    },
    signIn: {
      type: AuthenticateType,
      args: {
        email: {
          type: new GraphQLNonNull(GraphQLString)
        },
        password: {
          type: new GraphQLNonNull(GraphQLString)
        }
      },
      resolve(parentValue, args, { mongo }) {
        if (!isEmail(args.email)) {
          return new GraphQLError('Email is incorrect!');
        }
        
        if (!isValidRange(args.password, { min: 5 })) {
          return new GraphQLError('Password length is incorrect!');
        }
        
        const reqObject = {
          parentValue,
          args,
          context: {
            mongo
          }
        };
        
        return signIn(reqObject)
          .catch((error) => new GraphQLError(error));
      }
    },
    follow: {
      type: FollowType,
      args: {
        user_id: {
          type: GraphQLString
        },
        restaurant_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo, req }) {
        return verifyToken(req.headers.authorization)
          .then((user) => {
            const reqObject = {
              parentValue,
              args,
              context: {
                mongo
              }
            };
    
            return toggleFollowStatus(reqObject)
              .catch((error) => new GraphQLError(error));
          })
          .catch((error) => new GraphQLError(error));
      }
    },
    rate: {
      type: RateType,
      args: {
        user_id: {
          type: GraphQLString
        },
        restaurant_id: {
          type: GraphQLString
        },
        score_id: {
          type: GraphQLString
        }
      },
      resolve(parentValue, args, { mongo, req }) {
        return verifyToken(req.headers.authorization)
          .then((user) => {
            const reqObject = {
              parentValue,
              args,
              context: {
                mongo
              }
            };
    
            return rateRestaurant(reqObject)
              .catch((error) => new GraphQLError(error));
          })
          .catch((error) => new GraphQLError(error));
      }
    }
  })
});

module.exports = new GraphQLSchema({
  query: Query,
  mutation: Mutation
});