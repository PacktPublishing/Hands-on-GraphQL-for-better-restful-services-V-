const {
  GraphQLObjectType,
  GraphQLString
} = require('graphql');

const { UserType } = require('../user/schema');

const AuthenticateType = new GraphQLObjectType({
  name: 'authenticate',
  fields: () =>({
    user: {
      type: UserType
    },
    token: {
      type: GraphQLString
    }
  })
});

module.exports = {
  AuthenticateType
}