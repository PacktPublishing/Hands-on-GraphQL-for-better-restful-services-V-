const { encrypt, authenticate } = require('../../libs/security');

const {
  userByEmail
} = require('../user/resolver');

function signUp(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo
      .then((db) => {

        userByEmail(reqObject)
          .then((user) => {
            
            if (user) {
              return reject(`${args.email} email already exist!`);
            }

            encrypt(args.password)
              .then((encryptedPassword) => {
                args.password = encryptedPassword;
                
                db.collection('users').insertOne(args, (error, user) => {
                  if (error) {
                    console.log('Found problem while inserting user: ', error);
                    reject(error);
                  }
                  resolve(userByEmail(reqObject));
                });
              })
              .catch((error) => {
                console.log('Found problem while encrypting password: ', error);
                reject(error);
              });
            
          })
          .catch((error) => {
            console.log('Found problem while getting user\'s email: ', error);
            reject(error);
          });
      });
  });
}

function signIn(reqObject) {
  const {
    parentValue,
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {

    userByEmail(reqObject)
      .then((user) => {
        
        if (!user) {
          return reject(`${args.email} email do not exist!`);
        }
        
        authenticate(args.password, user)
          .then((userToken) => {
            if (userToken) {
              resolve({
                user: user,
                token: userToken
              });
            }
          })
          .catch((error) => {
            console.log('Found problem while authenticating user: ', error);
            reject(error);
          });
      })
      .catch((error) => {
        console.log('Found problem while signing user\'s email: ', error);
        reject(error);
      });

  });
}
module.exports = {
  signUp,
  signIn
}