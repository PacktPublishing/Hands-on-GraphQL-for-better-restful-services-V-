function userByEmail(reqObject) {
  const {
    context,
    args
  } = reqObject;
  
  return new Promise((resolve, reject) => {
    context.mongo
      .then((db) => {
        db.collection('users').findOne({
          email: args.email
        }, (error, result) => {
          
          if (error) {
            console.log('Found problem while getting the user\'s email: ', error);
            reject(error);
          }
          
          resolve(result);
        });
      });
  });
}

module.exports = {
  userByEmail
}