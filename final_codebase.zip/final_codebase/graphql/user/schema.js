const {
  GraphQLObjectType,
  GraphQLString,
} = require('graphql');

const UserType = new GraphQLObjectType({
  name: 'user',
  fields: () => ({
    _id: {
      type: GraphQLString
    },
    first_name: {
      type: GraphQLString
    },
    last_name: {
      type: GraphQLString
    },
    email: {
      type: GraphQLString
    }
  })
});

module.exports = {
  UserType
}