const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLInt
} = require('graphql');

const ScoreType = new GraphQLObjectType({
  name: 'score',
  fields: () =>({
    _id: {
      type: GraphQLString
    },
    grade: {
      type: GraphQLString
    },
    order: {
      type: GraphQLInt
    }
  })
});

module.exports = {
  ScoreType
}