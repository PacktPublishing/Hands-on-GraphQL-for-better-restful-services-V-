const { ObjectId } = require('mongodb');

function allScoreGrades(reqObject) {
  const {
    parentValue,
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      const sortOrder = { order: 1 };
      db.collection('scoreCategories').find().sort(sortOrder).toArray((error, results) => {
        if (error) { reject(error); }
        resolve(results);
      });
    });
  });
}

function avgRating(reqObject) {
  const {
    parentValue,
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {

      db.collection('rateRestaurants').aggregate([
        {
          $match: { restaurant_id: args.restaurant_id }
        },
        {
          $lookup: {
             from: 'scoreCategories',
             localField: 'score_id',
             foreignField: '_id',
             as: 'join'
          }
        }
        ]).toArray(function(error, results) {
          
          if (error) { reject(error); }
          
          let avg = 0;
          let sum = 0;

          if (!results.length) {
            avg = 0
            resolve({
              avg
            });
          }

          results.map((result) => {
            sum += result.join[0].score;
          });

          avg = (!sum) ? 0 : sum / results.length;

          if (sum) {
            avg = sum / results.length;
          }
        
          resolve({
            avg
          });
      });

    });
  });
}

module.exports = {
  allScoreGrades,
  avgRating
}