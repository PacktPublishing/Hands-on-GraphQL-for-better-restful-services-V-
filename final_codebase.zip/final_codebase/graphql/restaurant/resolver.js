const { ObjectId } = require('mongodb');
const { avgRating } = require('../scores/resolver');

function allRestaurants(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      db.collection('restaurants').find().skip(args.from).limit(args.pageSize).toArray((error, results) => {
        if (error) { reject(error); }
        resolve(results);
      });
    });
  });
}

function restaurant(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      db.collection('restaurants').findOne({
        _id: new ObjectId(args.restaurant_id)
      }, (error, result) => {
        if (error) { reject(error); }
        resolve(result);
      });
    });
  });
}

function followStatus(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      db.collection('followRestaurants').findOne({
        user_id: args.user_id,
        restaurant_id: args.restaurant_id
      }, (error, result) => {
        if (error) { reject(error); }

        resolve({
          isFollowing: (!result) ? false : true
        });
      });
    })
    .catch((error) => {
      console.error('Found problem with mongodb connector: ', error);
      reject('Either user_id or restaurant_id is not valid');
    });
  });
}

function toggleFollowStatus(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      followStatus(reqObject)
        .then((data) => {
          if (data.isFollowing) {
            resolve(_unFollowRestaurant(reqObject));
          } else {
            resolve(_followRestaurant(reqObject));
          }
        })
    });
  });
}

function _unFollowRestaurant(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {

      db.collection('followRestaurants').remove({
        user_id: { $eq: args.user_id },
        restaurant_id: { $eq: args.restaurant_id }
      }, (error, follow) => {
        if (error) {
          console.log('Found problem while following restaurant: ', error);
          reject(error);
        }
        
        resolve(followStatus(reqObject));
      });

    });
  });
}

function _followRestaurant(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      db.collection('followRestaurants').insertOne(args, (error, follow) => {
        if (error) {
          console.log('Found problem while following restaurant: ', error);
          reject(error);
        }
        
        resolve(followStatus(reqObject));
      });
    });
  });
}

function rateRestaurant(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      args.score_id = new ObjectId(args.score_id);
      
      db.collection('rateRestaurants').insertOne(args, (error, rate) => {
        if (error) {
          console.log('Found problem while rating restaurant: ', error);
          reject(error);
        }
        
        resolve(rateStatus(reqObject));
      });
    });
  });
}

function rateStatus(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    context.mongo.then((db) => {
      db.collection('rateRestaurants').findOne({
        user_id: args.user_id,
        restaurant_id: args.restaurant_id
      }, (error, result) => {
        if (error) { reject(error); }

        resolve({
          isRating: (!result) ? false : true
        });
      });
    })
    .catch((error) => {
      console.error('Found problem with mongodb connector: ', error);
      reject('Either user_id or restaurant_id is not valid');
    });
  });
}

function rateStats(reqObject) {
  const {
    context,
    args
  } = reqObject;

  return new Promise((resolve, reject) => {
    avgRating(reqObject)
      .then((data) => resolve(data))
      .catch((error) => reject(error));
  });
}

module.exports = {
  allRestaurants,
  restaurant,
  followStatus,
  toggleFollowStatus,
  rateRestaurant,
  rateStatus,
  rateStats
}