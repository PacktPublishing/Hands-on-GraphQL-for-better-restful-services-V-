const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLBoolean,
  GraphQLInt,
  GraphQLList,
  GraphQLFloat
} = require('graphql');

const StatsType = new GraphQLObjectType({
  name: 'stats',
  fields: () => ({
    avg: {
      type: GraphQLFloat
    }
  })
});

const RateType = new GraphQLObjectType({
  name: 'rate',
  fields: () => ({
    isRating: {
      type: GraphQLBoolean
    }
  })
});

const FollowType = new GraphQLObjectType({
  name: 'follow',
  fields: () => ({
    isFollowing: {
      type: GraphQLBoolean
    }
  })
});

const AddressType = new GraphQLObjectType({
  name: 'address',
  fields: () => ({
    street: {
      type: GraphQLString
    },
    city: {
      type: GraphQLString
    },
    zipcode: {
      type: GraphQLString
    },
    region: {
      type: GraphQLString
    },
    country: {
      type: GraphQLString
    },
    coord: {
      type: CoordinatesType
    }
  })
});

const CoordinatesType = new GraphQLObjectType({
  name: 'coordinate',
  fields: () => ({
    latitude: {
      type: GraphQLString
    },
    longitude: {
      type: GraphQLString
    }
  })
});

const RestaurantType = new GraphQLObjectType({
  name: 'restaurant',
  fields: () => ({
    _id: {
      type: GraphQLString
    },
    name: {
      type: GraphQLString
    },
    district: {
      type: GraphQLString
    },
    cuisine: {
      type: GraphQLString
    },
    address: {
      type: AddressType
    }
  })
});

module.exports = {
  RestaurantType,
  FollowType,
  StatsType,
  RateType
}